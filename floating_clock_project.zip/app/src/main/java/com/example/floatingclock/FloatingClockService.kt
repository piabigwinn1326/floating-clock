package com.example.floatingclock

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import java.util.*
import kotlin.math.abs
import kotlin.math.sqrt

class FloatingClockService : Service() {

    private lateinit var windowManager: WindowManager
    private var floatingView: View? = null
    private lateinit var tvTime: TextView
    private val handler = Handler(Looper.getMainLooper())
    // optimized: update every 100 ms to be light on CPU but still responsive for single-digit ms display
    private val updateIntervalMs = 100L

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(1, makeNotification())
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        addFloatingView()
        startClockUpdates()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val chan = NotificationChannel(
                "floating_clock_channel",
                "Floating Clock",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(chan)
        }
    }

    private fun makeNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, "floating_clock_channel")
            .setContentTitle("Floating Clock")
            .setContentText("Floating clock is running")
            .setSmallIcon(R.drawable.ic_stat_name)
            .setContentIntent(pi)
            .build()
    }

    private fun addFloatingView() {
        val inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        floatingView = inflater.inflate(R.layout.float_clock, null)
        tvTime = floatingView!!.findViewById(R.id.tv_time)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        // default position & scale tuned for 'M' medium size
        params.x = 80
        params.y = 220

        // drag + pinch-to-zoom support
        floatingView!!.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var lastAction = 0

            // for scaling
            private var scaleFactor = 1.0f
            private var prevDistance = 0f

            private fun distance(ev: MotionEvent): Float {
                if (ev.pointerCount >= 2) {
                    val dx = ev.getX(0) - ev.getX(1)
                    val dy = ev.getY(0) - ev.getY(1)
                    return sqrt(dx * dx + dy * dy)
                }
                return 0f
            }

            override fun onTouch(v: View?, event: MotionEvent): Boolean {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        lastAction = event.action
                        prevDistance = 0f
                        return true
                    }
                    MotionEvent.ACTION_POINTER_DOWN -> {
                        // start pinch
                        prevDistance = distance(event)
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (event.pointerCount == 1) {
                            // drag
                            params.x = initialX + (event.rawX - initialTouchX).toInt()
                            params.y = initialY + (event.rawY - initialTouchY).toInt()
                            windowManager.updateViewLayout(floatingView, params)
                        } else if (event.pointerCount >= 2) {
                            // pinch-to-zoom
                            val currDist = distance(event)
                            if (prevDistance > 10f && currDist > 10f) {
                                val scaleChange = currDist / prevDistance
                                scaleFactor *= scaleChange
                                // clamp scale
                                scaleFactor = scaleFactor.coerceIn(0.6f, 2.5f)
                                floatingView!!.scaleX = scaleFactor
                                floatingView!!.scaleY = scaleFactor
                            }
                            prevDistance = currDist
                        }
                        lastAction = event.action
                        return true
                    }
                    MotionEvent.ACTION_POINTER_UP -> {
                        // one finger released from pinch
                        prevDistance = 0f
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        // optional: snap to edge or treat as click if it was a tap
                        if (abs(event.rawX - initialTouchX) < 10 && abs(event.rawY - initialTouchY) < 10) {
                            // tap detected: could toggle visibility or open settings in future
                        }
                        lastAction = event.action
                        return true
                    }
                }
                return false
            }
        })

        windowManager.addView(floatingView, params)
    }

    private fun startClockUpdates() {
        handler.post(object : Runnable {
            override fun run() {
                updateTimeText()
                handler.postDelayed(this, updateIntervalMs)
            }
        })
    }

    private fun updateTimeText() {
        // use elapsedRealtime to avoid heavy Date/Calendar allocations
        val now = SystemClock.elapsedRealtime()
        val totalSeconds = now / 1000L
        val hours = (totalSeconds / 3600L) % 24L
        val minutes = (totalSeconds / 60L) % 60L
        val seconds = totalSeconds % 60L
        val millis = (now % 1000L).toInt()
        val lastMsDigit = millis / 100 // 0..9 single digit

        // blink colon around .5s for visual cue
        val blink = millis < 700
        val colon = if (blink) ":" else " "
        val display = String.format(Locale.getDefault(), "%02d%s%02d:%02d%d", hours, colon, minutes, seconds, lastMsDigit)

        tvTime.post { tvTime.text = display }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            floatingView?.let { windowManager.removeView(it) }
        } catch (e: Exception) {
            // ignore
        }
        handler.removeCallbacksAndMessages(null)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
