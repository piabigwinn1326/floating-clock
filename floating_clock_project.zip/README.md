# Floating iOS-style Clock (Android) - Ready-to-Build Project

This project creates a lightweight floating clock (iOS-style dark transparent) with:
- draggable overlay
- pinch-to-zoom (resize)
- single-digit milliseconds at the end (e.g. 19:59:5)
- optimized timer (SystemClock + Handler) for low CPU usage
- tuned default size: M (medium) — chosen by you

## How to build

### Option A — Online builder (quick, no PC setup)
1. Download the ZIP from this page.
2. Upload the project to a reputable online Android build service that accepts full Gradle projects, or use your own CI service.
   - Example approach: use a GitHub repo + GitHub Actions with Android build runner, or any cloud CI that supports Gradle.
3. Build and download the APK, then install on your phone.
> Note: Many 1-click "APK builder" websites only accept specific project types. If a site asks for an APK directly, use the local option below.

### Option B — Build locally (recommended for full control)
1. Install JDK 17+, Android SDK, and Android Studio (or command-line Gradle).
2. Open this project folder in Android Studio.
3. Let Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Find the APK in `app/build/outputs/apk/debug/app-debug.apk` and install it on your device.

## Permissions & First Run
- The app will request **Display over other apps** permission. Grant it in Settings when prompted.
- You may want to exempt the app from battery optimization on Samsung for long-running foreground service stability.

## Tuning
- To reduce CPU further, edit `updateIntervalMs` in `FloatingClockService.kt` (increase to 200–300 ms).
- To change default size or position, adjust `params.x`, `params.y`, or text size in `res/layout/float_clock.xml`.

---
Generated for Android 12–15 compatibility, default size: M (medium).
